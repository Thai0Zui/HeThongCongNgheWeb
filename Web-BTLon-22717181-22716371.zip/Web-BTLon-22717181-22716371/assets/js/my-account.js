function getInfor() {
    let currentUser = JSON.parse(localStorage.getItem("currentUser"));
    if (currentUser) {
        document.getElementById("accName").value = currentUser.nameCus;
        document.getElementById("accUser").value = currentUser.username;
        document.getElementById("accMail").value = currentUser.email;
        document.getElementById("accPass").value = currentUser.password;
    }
}

window.onload = function() {
    getInfor();
}