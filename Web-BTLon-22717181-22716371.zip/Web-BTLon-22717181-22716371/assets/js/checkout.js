function getInfor(){
    let currentUser = JSON.parse(localStorage.getItem("currentUser"));
    if (currentUser) {
        document.getElementById("accName").value = currentUser.nameCus;
        document.getElementById("accMail").value = currentUser.email;
    }
}
function getProduct(){
    let product = JSON.parse(localStorage.getItem("product"));
    if(product){
        document.getElementById("proName").innerHTML = product.name;
        document.getElementById("proPrice").innerHTML = product.price;
    }
}

window.onload= function() {
    getInfor();
    getProduct();
}

function checkout() {
    //Họ và tên
    let name = document.getElementById("accName");
    if(!name){
        document.getElementById("errNameC").innerHTML = "Họ và tên không được để trống";
        name.focus();
        return false;
    } else document.getElementById("errNameC").innerHTML = "*";

    //Địa chỉ nhà
    let addr1 = document.getElementById("checkAddr");
    if(!addr1.value){
        document.getElementById("errCheck1").innerHTML = "Địa chỉ không được để trống";
        addr1.focus();
        return false;
    } else document.getElementById("errCheck1").innerHTML = "*";

    //Quận huyện
    let addr2 = document.getElementById("checkAddr2");
    if(!addr2.value){
        document.getElementById("errCheck1").innerHTML = "Địa chỉ không được để trống";
        addr2.focus();
        return false;
    } else document.getElementById("errCheck1").innerHTML = "*";

    //Thành phố
    let city = document.getElementById("checkCity");
    if(!city.value){
        document.getElementById("errCheck2").innerHTML = "Thành phố không được để rỗng";
        city.focus();
        return false;
    } else document.getElementById("errCheck2").innerHTML = "*";

    //Số điện thoại
    let phone = document.getElementById("checkPhone");
    let phonePattern = /^[0][3-9]{1}[0-9]{8}$/;
    if(!phone.value){
        if(!phonePattern.test(phone)){
        document.getElementById("errCheck3").innerHTML = "Số điện thoại không được để rỗng";
        phone.focus();
        return false;}
    } else if(!phonePattern.test(phone.value)){
            document.getElementById("errCheck3").innerHTML = "Số điện thoại không tồn tại";
            phone.focus();
            return false;
    } else document.getElementById("errCheck3").innerHTML = "*";

    //Mail
    let mail = document.getElementById("checkMail");
    if(!mail.value){
        document.getElementById("errCheck4").innerHTML = "Mail không được để rỗng";
        mail.focus();
        return false;
    } else document.getElementById("errCheck4").innerHTML = "*";

    alert("Đặt hàng thành công");
    window.location.href = "index.html";
}