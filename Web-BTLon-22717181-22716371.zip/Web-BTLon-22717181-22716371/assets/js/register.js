function submitValid() {
    //Họ và Tên
    let name = document.getElementById("name");
    let fnamePattern = /^[A-Z][a-z]*(\s[A-Z][a-z]*)+$/;
    if(!name.value){
        document.getElementById("errName").innerHTML = "Họ và tên không được để rỗng";
        name.focus();
        return false;
    } else if(!fnamePattern.test(name.value)){
        document.getElementById("errName").innerHTML = "Họ và tên có ít nhất 2 từ, viết hoa đầu từ";
        name.focus();
        return false;
    }else document.getElementById("errName").innerHTML = "*";

    //Mail
    let mail = document.getElementById("mail");
    let mailPattern = /^([a-zA-Z0-9_\.-]+)@([a-zA-Z]+)\.([a-z\.]{3,5})+$/;
    if(!mail.value){
        document.getElementById("errMail").innerHTML = "Địa chỉ email không được rỗng.";
        mail.focus();
        return false;
    } else if(!mailPattern.test(mail.value)){
        document.getElementById("errMail").innerHTML = "Địa chỉ email không đúng định dạng.";
        mail.focus();
        return false;
    }else document.getElementById("errMail").innerHTML = "*";

    //Tên đăng nhập
    let uname = document.getElementById("uname");
    let namePattern = /^[A-Za-z0-9!@#$%^&*()]{3,16}$/;
    if(!uname.value){
        document.getElementById("errUser").innerHTML = "Tên đăng nhập không được để rỗng";
        uname.focus();
        return false;
    }else if (!namePattern.test(uname.value)) {
        document.getElementById("errUser").innerHTML = "Có ít nhất 3, nhiều nhất 16 ký tự và không có khoảng trắng.";
        uname.focus();
        return false;
    } else document.getElementById("errUser").innerHTML = "*";

    //Mật khẩu
    let pass = document.getElementById("pass");
    let passPattern = /^(?=.*[A-Z])(?=.*\d)(?=.*[@#$%^&*!])[A-Za-z\d@#$%^&*!]{8,}$/;
    if(!pass.value){
        document.getElementById("errPass").innerHTML = "Mật khẩu không được để rỗng.";
        pass.focus();
        return false;
    } else if (!passPattern.test(pass.value)) {
        document.getElementById("errPass").innerHTML = "Mật khẩu có ít nhất 1 chữ số, 1 ký tự in hoa, 1 ký tự đặc biệt.";
        pass.focus();
        return false;
    } else document.getElementById("errPass").innerHTML = "*";

    //Xác nhận mật khẩu
    let apass = document.getElementById("apass");
    if(!apass.value){
        document.getElementById("errAPass").innerHTML = "Xác nhận mật khẩu không được rỗng";
        apass.focus();
        return false;
    } else if (apass.value != pass.value) {
        document.getElementById("errAPass").innerHTML = "Không trùng khớp";
        apass.focus();
        return false;
    } else document.getElementById("errAPass").innerHTML = "*";

    let user = {nameCus: name.value, email: mail.value, username: uname.value, password: pass.value };
    let json = JSON.stringify(user);
    localStorage.setItem(uname.value, json);
    localStorage.setItem("currentUser", json);
    
    alert("Đăng Ký Thành Công");
    window.location.href = "login.html";
}