function setProduct(productName, unitPrice){
    let product = {name: productName, price: unitPrice};
    let json = JSON.stringify(product);
    localStorage.setItem("product", json);

    window.location.href = "checkout.html";
}