function submitValid() {

    //Tên đăng nhập
    let uname = document.getElementById("uname");
    let namePattern = /^[A-Za-z0-9!@#$%^&*()]{3,16}$/;
    if(!uname.value){
        document.getElementById("errUser").innerHTML = "Tên đăng nhập không được để rỗng";
        uname.focus();
        return false;
    }else if (!namePattern.test(uname.value)) {
        document.getElementById("errUser").innerHTML = "Có ít nhất 3, nhiều nhất 16 ký tự và không có khoảng trắng.";
        uname.focus();
        return false;
    } else document.getElementById("errUser").innerHTML = "*";

    //Mật khẩu
    let pass = document.getElementById("password");
    let passPattern = /^(?=.*[A-Z])(?=.*\d)(?=.*[@#$%^&*!])[A-Za-z\d@#$%^&*!]{8,}$/;
    if(!pass.value){
        document.getElementById("errPass").innerHTML = "Mật khẩu không được để rỗng.";
        pass.focus();
        return false;
    } else if (!passPattern.test(pass.value)) {
        document.getElementById("errPass").innerHTML = "Mật khẩu có ít nhất 1 chữ số, 1 ký tự in hoa, 1 ký tự đặc biệt.";
        pass.focus();
        return false;
    } else document.getElementById("errPass").innerHTML = "*";

    let user = JSON.parse(localStorage.getItem(uname.value));
    if (user && user.username === uname.value && user.password === password.value) {
        window.location.href = "index.html";
    } else {
        alert("Đăng Nhập Thất Bại");
    }
}    